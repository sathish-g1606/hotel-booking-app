<?php

function csv2json($data, $separator = "\t")
{
    file_put_contents(__DIR__ . '/tmp.csv', $data);
    $fname = __DIR__ . '/tmp.csv';
    if (!($fp = fopen($fname, 'r'))) {
        die("Can't open file...");
    }

    //read csv headers
    $key = fgetcsv($fp, "1024", $separator);

    // parse csv rows into array
    $json = array();
    while ($row = fgetcsv($fp, "1024", $separator)) {
        $json[] = array_combine($key, $row);
    }

    // release file handle
    fclose($fp);
    return $json;
}
