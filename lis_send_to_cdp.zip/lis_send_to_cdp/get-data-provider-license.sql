
--select * from cs_idmap where external_id IN('10000207') order by external_id asc

select 
a.userId, a.lms_user_id, a.lms_user_email, a.userStatus, a.lms_assignment_id entryLicenseId,  a.compliant_until compliantUntil, a.ecard_until ecardUntil, 
a.last_completion completed_at, a.time_zone, a.lis_outcome_service_url,a.depCompliantUntil, a.manifest_id,
a.dependent_attempt_id, a.dep_manifestId,
a.providerAttemptId,
case 
  when a.completed_at is not null then a.completed_at
  when a.completed_at is  null and a.last_completion is not null then IIF( a.last_completion is null, 'c NULL',a.last_completion)
  when a.completed_at is  null and a.last_completion is null then IIF( a.cs_progress_completion is null, 'NULL',a.cs_progress_completion)
  when a.completed_at is  null and a.last_completion is null and a.cs_progress_completion is null  then 'NULL'
End as last_activity, currentStartDate mocStartDate

from (SELECT 
            csu.id userId,
            csu.lms_user_id,
            csu.lms_user_email,
            csu.active userStatus,
            -- csa.time_zone,
            (SELECT TOP 1 time_zone FROM cs_attempt WHERE user_id = csa.user_id AND time_zone IS NOT NULL) time_zone,
            csa.id providerAttemptId,
            csa.lis_outcome_service_url,
            csb.compliant_until depCompliantUntil,
            csa.manifest_id,
            IIF(CONVERT(varchar,csa.compliant_until, 21) <> '9999-12-31 00:00:00.0000000',
            CONVERT(varchar,csa.compliant_until, 21), NULL) AS compliant_until,
            CASE WHEN  CONVERT(varchar,csa.compliant_until, 21) <> '9999-12-31 00:00:00.0000000'
            AND csa.dep_manifestId IS NOT NULL
           AND csa.dependent_attempt_id IS NULL THEN null
           ELSE
            DATEADD(MONTH, ISNULL(csa.compliant_offset, 0),
            IIF(csb.compliant_until < csa.compliant_until,
            CONVERT(datetime,csb.compliant_until,112) ,
            CONVERT(datetime,csa.compliant_until, 112)
            ))
            END  AS ecard_until,
             CONVERT(varchar,csa.completed_at, 21) AS completed_at,
            csa.resource_link_id AS lms_assignment_id,
             (SELECT TOP 1 CONVERT(varchar,completed, 21) AS completed
                FROM cs_moc_progress csp
                WHERE csp.attempt_id = csa.id
                ORDER BY csp.completed DESC
                ) AS last_completion,
                
                (SELECT TOP 1 CONVERT(varchar,completed, 21) AS completed
                FROM cs_progress cs
                WHERE cs.attempt_id = csa.id and step = 'total'
                ORDER BY cs.completed DESC
                ) AS cs_progress_completion,
                (SELECT TOP 1 CONVERT(varchar,start_date, 21) AS currentStartDate
                FROM cs_moc_progress csp
                WHERE csp.attempt_id = csa.id AND csp.completed IS NOT NULL
                ORDER BY csp.start_date DESC
                ) AS currentStartDate,
                csa.dependent_attempt_id as dependent_attempt_id,
                csa.dep_manifestId as dep_manifestId,
				csa.org_id
             FROM cs_attempt csa 
             LEFT JOIN cs_attempt csb ON csa.dependent_attempt_id = csb.id
             LEFT JOIN cs_user csu ON csu.id = csa.user_id
             WHERE csa.compliant_until is not null and   csa.resource_link_id is not null and len(csa.resource_link_id) <= 15  
             AND csa.active = 1
			--and csa.org_id IN('11D5242E-E8A2-4791-BA05-4A5A2562D1BD')
      and csa.resource_link_id IN('20358299')
			--and csa.manifest_id IN('manifest/rqi_bls_entry_moc_aha','manifest/rqi_als_entry_moc_aha','manifest/rqi_pals_entry_moc_aha','manifest/rqi_bls_ready_moc_aha','manifest/rqi_als_ready_moc_aha','manifest/rqi_pals_ready_moc_aha','manifest/hc_2020_acls_aha_complete')
      -- AND csa.manifest_id IN('manifest/rqi_pals_provider_moc_aha','manifest/rqi_als_provider_moc_aha','manifest/rqi_bls_provider_moc_aha','manifest/bfb_rqi_adult_infant_curriculum_de')
      --and csa.completed_at is not null
			 )  a 
		
SELECT * FROM cs_lis_token

-- To get timeZone
SELECT DISTINCT time_zone, user_id
FROM cs_attempt
WHERE user_id IN ('70844370-5d36-ef11-86c3-0022488eab8e','b35204ef-8aee-ee11-aaf0-000d3a3cf657','9cb88b8f-470d-ef11-96f5-0022488e1ce6','17a760f6-90d1-ee11-85fa-002248909106','422a7a0b-b22d-ef11-86c3-0022488eab8e','1a697ca4-5732-ef11-86c3-0022488eab8e')
AND time_zone IS NOT NULL