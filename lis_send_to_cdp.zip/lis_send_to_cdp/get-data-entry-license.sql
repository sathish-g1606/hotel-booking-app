-- API: http://localhost/createProvider/lis_send.php

--  'manifest/rqi_als_provider_moc_aha', 'manifest/rqi_pals_provider_moc_aha', 'manifest/rqi_bls_responder_moc_aha'

SELECT DISTINCT cu.id userId, cu.lms_user_id, cu.lms_user_email, cu.active userStatus, entry.resource_link_id entryLicenseId, moc.start_date mocStartDate, CONVERT(DATE, provider.compliant_until) compliantUntil, CONVERT(DATE, provider.compliant_until) ecardUntil1, provider.id providerAttemptId, entry.start_date, entry.time_zone, entry.completed_at,
    entry.lis_outcome_service_url, dep.compliant_until depCompliantUntil,
    IIF(provider.dep_manifestId IS NULL, 
     CONVERT(DATE, provider.compliant_until),
     IIF(dep.compliant_until IS NULL, NULL, 
    IIF(dep.compliant_until < provider.compliant_until, 
        CONVERT(DATE, dep.compliant_until), 
        CONVERT(DATE, provider.compliant_until)))) ecardUntil,
    provider.manifest_id, provider.dep_manifestId, provider.dependent_attempt_id, dep.resource_link_id depResourceLinkId, dep.active depActiveStatus,
    provider.start_date providerStartDate, provider.resource_link_id providerLicenseId
FROM cs_attempt provider
    JOIN cs_attempt entry ON entry.user_id = provider.user_id
    LEFT JOIN cs_attempt dep ON dep.manifest_id = provider.dep_manifestId AND (dep.id = provider.dependent_attempt_id OR dep.id = entry.dependent_attempt_id) AND dep.active = 1
    JOIN cs_moc_progress moc ON moc.attempt_id = entry.id
    JOIN cs_user cu ON cu.id = entry.user_id
WHERE 
    provider.manifest_id = (CASE
        WHEN entry.manifest_id IN ('manifest/rqi_bls_entry_moc_aha', 'manifest/rqi_bls_ready_moc_aha', 'manifest/rqi_provider_2025_aha_moc_entry', 'manifest/rqi_provider_2025_aha_moc_prep') THEN 'manifest/rqi_bls_provider_moc_aha'
        WHEN entry.manifest_id IN ('manifest/rqi_als_entry_moc_aha', 'manifest/rqi_als_ready_moc_aha', 'manifest/rqi_als_2025_aha_moc_entry', 'manifest/rqi_als_2025_aha_moc_prep') THEN 'manifest/rqi_als_provider_moc_aha'
        WHEN entry.manifest_id IN ('manifest/rqi_pals_entry_moc_aha', 'manifest/rqi_pals_ready_moc_aha', 'manifest/rqi_pals_2025_aha_moc_entry', 'manifest/rqi_pals_2025_aha_moc_prep') THEN 'manifest/rqi_pals_provider_moc_aha'
        WHEN entry.manifest_id IN ('manifest/rqi_bls_responder_entry_moc_aha') THEN 'manifest/rqi_bls_responder_moc_aha'
        WHEN entry.manifest_id IN ('manifest/rqi_nrp_tpiece_bvm_entry_moc', 'manifest/rqi_nrp_tpiece_bvm_prep_moc') THEN 'manifest/rqi_nrp_tpiece_bvm_moc'
        WHEN entry.manifest_id IN ('manifest/rqi_nrp_tpiece_entry_moc', 'manifest/rqi_nrp_tpiece_prep_moc') THEN 'manifest/rqi_nrp_tpiece_moc'
        --  WHEN entry.manifest_id IN ('manifest/rqi_t_entry_moc','manifest/rqi_t_prep_moc','manifest/rqi_t_entry_exam_moc','manifest/rqi_t_entry_pd_moc','manifest/rqi_t_prep_moc_v1') THEN 'manifest/rqi_t_perpetual_moc'
        WHEN entry.manifest_id IN ('manifest/rqi_provider_2025_aha_moc_entry_hsfc', 'manifest/rqi_provider_2025_aha_moc_prep_hsfc') THEN 'manifest/rqi_bls_provider_moc_aha_hsfc'
        WHEN entry.manifest_id IN ('manifest/rqi_als_2025_aha_moc_entry_hsfc', 'manifest/rqi_als_2025_aha_moc_prep_hsfc') THEN 'manifest/rqi_als_provider_moc_aha_hsfc'
        WHEN entry.manifest_id IN ('manifest/rqi_pals_2025_aha_moc_entry_hsfc', 'manifest/rqi_pals_2025_aha_moc_prep_hsfc') THEN 'manifest/rqi_pals_provider_moc_aha_hsfc'
        WHEN entry.manifest_id IN ('manifest/rqi_nln_provider_2025_aha_moc_prep', 'manifest/rqi_nln_provider_2025_aha_moc_entry') THEN 'manifest/rqi_nln_bls_provider_moc_aha'
        WHEN entry.manifest_id IN ('manifest/rqi_nln_als_2025_aha_moc_entry', 'manifest/rqi_nln_als_2025_aha_moc_prep') THEN 'manifest/rqi_nln_als_provider_moc_aha'
        WHEN entry.manifest_id IN ('manifest/rqi_nln_pals_2025_aha_moc_entry', 'manifest/rqi_nln_pals_2025_aha_moc_prep') THEN 'manifest/rqi_nln_pals_provider_moc_aha'
        ELSE entry.manifest_id
    END)
    AND entry.active = 1
    AND provider.user_id = entry.user_id
    -- SELECT DISTINCT(user_id)
    -- FROM cs_attempt
    -- WHERE manifest_id IN ('manifest/rqi_bls_entry_moc_aha', 'manifest/rqi_bls_ready_moc_aha', 'manifest/rqi_provider_2025_aha_moc_entry', 'manifest/rqi_provider_2025_aha_moc_prep','manifest/rqi_als_entry_moc_aha', 'manifest/rqi_als_ready_moc_aha', 'manifest/rqi_als_2025_aha_moc_entry', 'manifest/rqi_als_2025_aha_moc_prep','manifest/rqi_pals_entry_moc_aha', 'manifest/rqi_pals_ready_moc_aha', 'manifest/rqi_pals_2025_aha_moc_entry', 'manifest/rqi_pals_2025_aha_moc_prep'	,'manifest/rqi_bls_responder_entry_moc_aha','manifest/rqi_nrp_tpiece_bvm_entry_moc', 'manifest/rqi_nrp_tpiece_bvm_prep_moc','manifest/rqi_provider_2025_aha_moc_entry_hsfc', 'manifest/rqi_provider_2025_aha_moc_prep_hsfc','manifest/rqi_als_2025_aha_moc_entry_hsfc', 'manifest/rqi_als_2025_aha_moc_prep_hsfc'	,'manifest/rqi_pals_2025_aha_moc_entry_hsfc', 'manifest/rqi_pals_2025_aha_moc_prep_hsfc','manifest/rqi_nln_provider_2025_aha_moc_prep', 'manifest/rqi_nln_provider_2025_aha_moc_entry','manifest/rqi_nln_als_2025_aha_moc_entry', 'manifest/rqi_nln_als_2025_aha_moc_prep','manifest/rqi_nln_pals_2025_aha_moc_entry', 'manifest/rqi_nln_pals_2025_aha_moc_prep')
    --     AND active = 1 AND completed_at IS NOT NULL
    -- )
    AND entry.completed_at IS NOT NULL
    AND provider.active = 1
    AND entry.resource_link_id IN ('28925355')
    -- provider.resource_link_id IN ('29681530','29679162')
    -- AND YEAR(entry.completed_at) = '2024' 
    -- AND provider.dependent_attempt_id IS NOT NULL
ORDER BY cu.id ASC



SELECT * FROM cs_lis_token

-- SELECT id, manifest_id, resource_link_id, active, start_date, completed_at, compliant_until, dep_manifestId, dependent_attempt_id FROM cs_attempt WHERE user_id ='f2082b85-890a-ea11-add2-0003ff179faa' AND (LEN(resource_link_id) < 15 OR resource_link_id IS NULL)


-- SELECT TOP 20 id, manifest_id, resource_link_id, user_id, dep_manifestId, dependent_attempt_id, start_date, completed_at, compliant_until
-- FROM cs_attempt
-- WHERE user_id IN (
-- SELECT user_id
--     FROM cs_attempt
--     WHERE manifest_id IN ('manifest/rqi_als_provider_moc_aha', 'manifest/rqi_pals_provider_moc_aha', 'manifest/rqi_als_entry_moc_aha', 'manifest/rqi_als_ready_moc_aha', 'manifest/rqi_als_2025_aha_moc_entry', 'manifest/rqi_als_2025_aha_moc_prep',
-- 'manifest/rqi_pals_entry_moc_aha', 'manifest/rqi_pals_ready_moc_aha', 'manifest/rqi_pals_2025_aha_moc_entry', 'manifest/rqi_pals_2025_aha_moc_prep') AND dep_manifestId IS NULL AND active = 1
-- ) AND manifest_id = 'manifest/rqi_bls_provider_moc_aha' AND active = 1


-- SELECT id, resource_link_id, manifest_id, start_date, completed_at, compliant_until, dep_manifestId, dependent_attempt_id FROM cs_attempt
-- WHERE user_id = 'acf841ab-9d08-ef11-96f5-0022488e1ce6'
-- AND active = 1
-- AND manifest_id IN ('manifest/rqi_als_provider_moc_aha', 'manifest/rqi_pals_provider_moc_aha', 'manifest/rqi_als_entry_moc_aha', 'manifest/rqi_als_ready_moc_aha', 'manifest/rqi_als_2025_aha_moc_entry', 'manifest/rqi_als_2025_aha_moc_prep',
-- 'manifest/rqi_pals_entry_moc_aha', 'manifest/rqi_pals_ready_moc_aha', 'manifest/rqi_pals_2025_aha_moc_entry', 'manifest/rqi_pals_2025_aha_moc_prep', 'manifest/rqi_bls_provider_moc_aha', 'manifest/rqi_bls_entry_moc_aha', 'manifest/rqi_bls_ready_moc_aha', 'manifest/rqi_provider_2025_aha_moc_entry', 'manifest/rqi_provider_2025_aha_moc_prep')
