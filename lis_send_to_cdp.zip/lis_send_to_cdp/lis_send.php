<?php
ini_set('display_errors', true);
ini_set('memory_limit', -1);
ini_set('max_execution_time', 0);
ini_set('output_buffering', 'off');
ini_set('implicit_flush', true);
ob_implicit_flush(true);

require_once "./csv2json.php";

if (!empty($_POST) && !empty($_POST['data']) && !empty($_POST['token'])) {
    $content = $_POST['data'];

    foreach ([",", "\t"] as $key => $value) {
        $csv2Json = csv2json($content, $value);
        if (!empty($csv2Json) && count($csv2Json[0]) > 1) {
            break;
        }
    }

    $AtimeZone = [];
    if (isset($_POST['timezone']) && !empty($_POST['timezone'])) {
        $timeZone = json_decode($_POST['timezone'], 1);
        // print_r($timeZone);die;
        foreach ($timeZone as $key => $value) {
            $AtimeZone[$value['user_id']] = $value['time_zone'];
        }
    }

    if (!empty($csv2Json)) {
        $AmessageType = ["completion", "compliance"];
        // $AmessageType = ["compliance"];
        $sampleLISFormat = '{"messageIdentifier":"","messageType":"","operationRefIdentifier":"replaceResult","result":{"complianceInfo":{"certificateUrl":"","completedAt":"","completionLis":false,"customStartDate":"","lmsAssignmentId":"","sessionId":null,"compliantUntil":"","ecardUntil":""},"resultScore":1,"sourcedId":"","sourcedType":"course","vsimMetaInfo":{"assignmentId":null,"blobId":null,"isvSimCompleted":false,"nonVSimCompletionStatus":false,"scoId":null,"topicQuiz":false,"topicVSim":false,"vsimMeta":null}},"version":"v2.0"}';

        // $curl = curl_init();
        echo "<pre>";

        foreach ($csv2Json as $key => $value) {
            foreach ($AmessageType as $k => $val) {
                $URL = $value['lis_outcome_service_url'] . "/" . $val;
                // echo "<b>URL: </b>" . $URL . "<br/>";
                $LISFormat = json_decode($sampleLISFormat, 1);
                if ($val === "completion") {
                    unset($LISFormat['result']['complianceInfo']['compliantUntil']);
                    unset($LISFormat['result']['complianceInfo']['ecardUntil']);
                } else {
                    $LISFormat['result']['complianceInfo']['compliantUntil'] = $value['compliantUntil'];
                    $LISFormat['result']['complianceInfo']['ecardUntil'] = ($value['ecardUntil'] == "null" || $value['ecardUntil'] == "NULL") ? null : $value['ecardUntil'];
                }

                $LISFormat['messageIdentifier'] = rand(1e10, 1e11);
                $LISFormat['messageType'] = $val;
                $LISFormat['result']['sourcedId'] = $value['entryLicenseId'];
                $LISFormat['result']['complianceInfo']['certificateUrl'] = "/en-US/getsignedcert/$value[providerAttemptId]|638518654851730000|ca0280919f28dd6b/400/moc";
                $LISFormat['result']['complianceInfo']['completedAt'] = $value['completed_at'];
                $LISFormat['result']['complianceInfo']['completionLis'] = ($val === "completion");
                $timeZone = ($value['time_zone'] == "NULL") ? $AtimeZone[$value["userId"]] : $value['time_zone'];
                if (empty($timeZone)) {
                    print_r($$value);
                    die;
                }
                $LISFormat['result']['complianceInfo']['customStartDate'] = convertCustomStartDate($value['mocStartDate'], $timeZone);
                $LISFormat['result']['complianceInfo']['lmsAssignmentId'] = $value['entryLicenseId'];
                $data = json_encode($LISFormat);


                echo $curl = "curl --location --request POST '$URL' \
--header 'Accept: application/json' \
--header 'Authorization: Bearer " . $_POST['token'] . "' \
--header 'Content-Type: application/json' \
--data-raw '$data'";
                echo "\n";

                file_put_contents("./dump/lis_send_dump." . time() . ".txt", $curl, FILE_APPEND);

                ob_flush();
                flush();
            }
        }
        die("</pre>Done");
    }
}

function convertCustomStartDate($date, $timezone)
{
    $date = str_replace(".0000000", "", $date);
    // Create a DateTime object with the UTC time
    $utcTime = new DateTime($date, new DateTimeZone('UTC'));

    // Create a DateTimeZone object for the US/Central timezone
    $centralTimezone = new DateTimeZone($timezone);

    // Convert the DateTime object to the US/Central timezone
    $centralTime = $utcTime->setTimezone($centralTimezone);

    // Output the converted time in the desired format
    return $centralTime->format('Y-m-d\TH:i:sP');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LIS Send Cron</title>
</head>

<body>
    <form action="./lis_send.php" method="post">
        <textarea name="data" id="data" cols="30" rows="10" placeholder="NeedToSendLis_Dump-1.sql"></textarea>
        <textarea name="timezone" id="timezone" cols="30" rows="10" placeholder="col: time_zone, user_id json format"></textarea>
        <div>
            <label for="token">Token: </label>
            <input name="token" id="token" value="" />
        </div>
        <button type="submit">Submit</button>
    </form>
</body>

</html>
